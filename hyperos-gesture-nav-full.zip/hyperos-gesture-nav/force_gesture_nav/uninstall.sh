#!/system/bin/sh
# Restore defaults on module removal
settings put global force_fsg_nav_bar 0
pkill -f "force_gesture_nav"
rm -f /data/local/tmp/force_gesture_nav.log
