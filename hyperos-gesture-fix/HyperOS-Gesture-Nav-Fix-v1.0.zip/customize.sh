#!/system/bin/sh
SKIPUNZIP=1

ui_print ""
ui_print "============================================"
ui_print "  HyperOS Gesture Navigation Fix v1.0"
ui_print "  Third-party launcher gesture support"
ui_print "============================================"
ui_print ""

# Extract all module files
ui_print "[*] Installing module files..."
unzip -o "$ZIPFILE" -d "$MODPATH" >/dev/null 2>&1

# Set permissions
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
[ -f "$MODPATH/uninstall.sh" ] && set_perm "$MODPATH/uninstall.sh" 0 0 0755

ui_print "[+] Module installed!"
ui_print ""
ui_print "  Reboot to activate."
ui_print "  Then set any launcher as default."
ui_print "  Gesture navigation will stay active!"
ui_print ""
ui_print "  To revert: uninstall this module & reboot"
ui_print "============================================"
ui_print ""
