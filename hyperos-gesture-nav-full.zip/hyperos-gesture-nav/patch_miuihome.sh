#!/bin/bash
# patch_miuihome.sh — Patches MiuiHome APK for gesture navigation with third-party launchers
# Usage: ./patch_miuihome.sh <MiuiHome.apk> [output.apk]
#
# Requirements: Java 8+, smali.jar (included in tools/), apktool, zip

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SMALI_JAR="${SCRIPT_DIR}/tools/smali.jar"
INPUT_APK="$1"
OUTPUT_APK="${2:-MiuiHome_patched.apk}"
WORK_DIR=$(mktemp -d)

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
fail() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# Validate
[ -z "$INPUT_APK" ] && fail "Usage: $0 <MiuiHome.apk> [output.apk]"
[ ! -f "$INPUT_APK" ] && fail "File not found: $INPUT_APK"
which java >/dev/null 2>&1 || fail "Java not found. Install JDK 8+."
which apktool >/dev/null 2>&1 || fail "apktool not found. Install: sudo apt install apktool"
[ ! -f "$SMALI_JAR" ] && fail "smali.jar not found at $SMALI_JAR. Download from https://github.com/baksmali/smali/releases"

log "Input: $INPUT_APK"
log "Output: $OUTPUT_APK"
log "Working directory: $WORK_DIR"

# Step 1: Decompile
log "Decompiling APK..."
apktool d "$INPUT_APK" -o "$WORK_DIR/decompiled" -f 2>&1 | tail -3

# Step 2: Locate target files
BUILDCONFIG="$WORK_DIR/decompiled/smali/com/miui/home/common/utils/BuildConfigUtils.smali"
BASERECENTS="$WORK_DIR/decompiled/smali_classes2/com/miui/home/recents/BaseRecentsImpl.smali"
NAVSTUB="$WORK_DIR/decompiled/smali_classes2/com/miui/home/recents/NavStubView.smali"

# Check for HyperOS 2 path (older class name)
if [ ! -f "$BUILDCONFIG" ]; then
    BUILDCONFIG="$WORK_DIR/decompiled/smali/com/miui/home/launcher/common/Utilities.smali"
    if [ ! -f "$BUILDCONFIG" ]; then
        fail "Cannot find BuildConfigUtils or Utilities smali file. Is this a MiuiHome APK?"
    fi
    warn "Found legacy class path (HyperOS 1/2). Adjusting patches..."
fi

[ ! -f "$BASERECENTS" ] && fail "Cannot find BaseRecentsImpl.smali"
[ ! -f "$NAVSTUB" ] && fail "Cannot find NavStubView.smali"

# Step 3: Apply patches
log "Applying patches..."

python3 << PATCHEOF
import sys

def patch_file(path, old, new, name):
    with open(path, 'r') as f:
        content = f.read()
    if old in content:
        content = content.replace(old, new)
        with open(path, 'w') as f:
            f.write(content)
        print(f"  ✓ {name}")
        return True
    else:
        print(f"  ✗ {name} — pattern not found (may need manual adjustment)")
        return False

success = 0
total = 0

# --- PATCH 1: isUseMiuiHomeAsDefaultHome ---
total += 1
# Try HyperOS 3 class name first
bc = "$BUILDCONFIG"
if patch_file(bc,
    '''    invoke-static {}, Lcom/miui/home/common/utils/BuildConfigUtils;->getCurrentDefaultHomePackageName()Ljava/lang/String;

    move-result-object p0

    const-string v0, "com.miui.home"

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    return p0
.end method''',
    '''    # PATCHED: Always return true for gesture navigation
    const/4 p0, 0x1

    return p0
.end method''',
    "Patch 1: isUseMiuiHomeAsDefaultHome → true"):
    success += 1

# --- PATCH 2: isUsePocoHomeAsDefaultHome ---
total += 1
if patch_file(bc,
    '''    invoke-static {p0}, Lcom/miui/home/common/utils/BuildConfigUtils;->getDefaultHomePackageName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "com.mi.android.globallauncher"

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    return p0
.end method''',
    '''    # PATCHED: Always return true for gesture navigation
    const/4 p0, 0x1

    return p0
.end method''',
    "Patch 2: isUsePocoHomeAsDefaultHome → true"):
    success += 1

# --- PATCH 3: setIsUseMiuiHomeAsDefaultHome ---
total += 1
br = "$BASERECENTS"
if patch_file(br,
    '''.method public setIsUseMiuiHomeAsDefaultHome(Z)V
    .locals 2

    .line 810''',
    '''.method public setIsUseMiuiHomeAsDefaultHome(Z)V
    .locals 2

    # PATCHED: Force parameter to true
    const/4 p1, 0x1

    .line 810''',
    "Patch 3: setIsUseMiuiHomeAsDefaultHome → forced true"):
    success += 1

# --- PATCH 4: Init-time field assignment ---
total += 1
if patch_file(br,
    '''    if-eqz v0, :cond_3

    move v4, v2

    :cond_3
    iput-boolean v4, p0, Lcom/miui/home/recents/BaseRecentsImpl;->mIsUseMiuiHomeAsDefaultHome:Z''',
    '''    if-eqz v0, :cond_3

    move v4, v2

    :cond_3
    # PATCHED: Force true at init
    const/4 v4, 0x1
    iput-boolean v4, p0, Lcom/miui/home/recents/BaseRecentsImpl;->mIsUseMiuiHomeAsDefaultHome:Z''',
    "Patch 4: Init mIsUseMiuiHomeAsDefaultHome → forced true"):
    success += 1

# --- PATCH 5: Recents fallback (cond_8) ---
total += 1
ns = "$NAVSTUB"
if patch_file(ns,
    '''    :cond_8
    invoke-virtual/range {p0 .. p0}, Lcom/miui/home/recents/NavStubView;->performAppToHome()V

    .line 4896
    :cond_9
    :goto_4
    invoke-static {}, Lcom/miui/home/common/hapticfeedback/HapticFeedbackCompat;->getInstance()Lcom/miui/home/common/hapticfeedback/HapticFeedbackCompat;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/miui/home/common/hapticfeedback/HapticFeedbackCompat;->performHomeGestureAccessibilitySwitch(Landroid/view/View;)V

    return-void
.end method''',
    '''    :cond_8
    # PATCHED: Launch RecentsActivity directly instead of falling back to home
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    new-instance v11, Landroid/content/Intent;

    invoke-direct {v11}, Landroid/content/Intent;-><init>()V

    new-instance v12, Landroid/content/ComponentName;

    const-string v13, "com.miui.home"

    const-string v14, "com.miui.home.recents.RecentsActivity"

    invoke-direct {v12, v13, v14}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v11, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const v12, 0x14010000

    invoke-virtual {v11, v12}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    nop

    nop

    nop

    invoke-virtual {v10, v11}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 4896
    :cond_9
    :goto_4
    invoke-static {}, Lcom/miui/home/common/hapticfeedback/HapticFeedbackCompat;->getInstance()Lcom/miui/home/common/hapticfeedback/HapticFeedbackCompat;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/miui/home/common/hapticfeedback/HapticFeedbackCompat;->performHomeGestureAccessibilitySwitch(Landroid/view/View;)V

    return-void
.end method''',
    "Patch 5: Recents fallback → launches RecentsActivity"):
    success += 1

# --- PATCH 6: Bottom gesture zone height ---
total += 1
p6a = patch_file(ns,
    'const/high16 v1, 0x41a40000    # 20.5f',
    'const/high16 v1, 0x420c0000    # 35.0f  PATCHED: increased gesture zone',
    "Patch 6a: Hidden gesture line height 20.5dp → 35dp")

p6b = patch_file(ns,
    '''    sget-boolean v0, Lcom/miui/home/common/device/DeviceConfigs;->IS_FOLD_DEVICE_WITH_SHELL:Z

    const/high16 v1, 0x41c80000    # 25.0f

    if-eqz v0, :cond_0''',
    '''    sget-boolean v0, Lcom/miui/home/common/device/DeviceConfigs;->IS_FOLD_DEVICE_WITH_SHELL:Z

    const/high16 v1, 0x420c0000    # 35.0f  PATCHED: increased gesture zone

    if-eqz v0, :cond_0''',
    "Patch 6b: Default gesture height 25dp → 35dp")

if p6a or p6b:
    success += 1

print(f"\n{'='*50}")
print(f"Patches applied: {success}/{total}")
if success < total:
    print(f"WARNING: Some patches failed. The APK may be a different version.")
    print(f"Check the patch files in patches/ for the expected patterns.")
print(f"{'='*50}")
PATCHEOF

# Step 4: Reassemble DEX files
log "Reassembling DEX files..."
SMALI_DIRS=$(find "$WORK_DIR/decompiled" -maxdepth 1 -name "smali*" -type d | sort)
for SDIR in $SMALI_DIRS; do
    DNAME=$(basename "$SDIR")
    if [ "$DNAME" = "smali" ]; then
        DEXNAME="classes.dex"
    else
        DEXNAME="${DNAME/smali_/}.dex"
    fi
    log "  Assembling $DEXNAME from $DNAME..."
    java -jar "$SMALI_JAR" assemble "$SDIR" -o "$WORK_DIR/$DEXNAME" 2>&1 | tail -1
done

# Step 5: Inject DEX files into APK copy
log "Injecting patched DEX files into APK..."
cp "$INPUT_APK" "$OUTPUT_APK"
cd "$WORK_DIR"
zip -j "$SCRIPT_DIR/$OUTPUT_APK" classes*.dex 2>&1 | tail -3

# Cleanup
rm -rf "$WORK_DIR"

log "Done! Patched APK: $OUTPUT_APK"
echo ""
echo "Next steps:"
echo "  1. Push to device:  adb push $OUTPUT_APK /sdcard/"
echo "  2. Replace in module: adb shell \"su -c 'cp /sdcard/$OUTPUT_APK /data/adb/modules/YOUR_MODULE/system/product/priv-app/MiuiHome/MiuiHome.apk'\""
echo "  3. Set permissions:  adb shell \"su -c 'chmod 644 /data/adb/modules/YOUR_MODULE/system/product/priv-app/MiuiHome/MiuiHome.apk'\""
echo "  4. Reboot:          adb reboot"
