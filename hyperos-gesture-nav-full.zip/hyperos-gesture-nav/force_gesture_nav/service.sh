#!/system/bin/sh
# Force Gesture Navigation for Third-Party Launchers
# HyperOS 2/3 — KernelSU / Magisk Module
#
# This module forces gesture navigation to remain active when a
# third-party launcher is set as the default home app.

MODDIR=${0%/*}
LOG=/data/local/tmp/force_gesture_nav.log

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [ForceGesture] $1" >> "$LOG"
}

# Truncate log on boot
echo "" > "$LOG"
log "Module started"

# Wait for system to be fully booted
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
log "Boot completed, waiting for SystemUI..."

# Give SystemUI and launcher time to fully initialize
sleep 10

apply_gesture_settings() {
    # 1. Force enable the gestural navigation overlay (AOSP side)
    cmd overlay enable com.android.internal.systemui.navbar.gestural 2>/dev/null

    # 2. Disable three-button overlay if it got re-enabled
    cmd overlay disable com.android.internal.systemui.navbar.threebutton 2>/dev/null

    # 3. Force the MIUI/HyperOS gesture flag
    settings put global force_fsg_nav_bar 1

    # 4. Set navigation mode to gesture (2 = gesture, 0 = 3-button)
    settings put secure navigation_mode 2

    # 5. Ensure gesture version flags are set
    settings put global use_gesture_version_three 1
    settings put global hide_gesture_line 1

    log "Gesture settings applied"
}

# Apply on boot
apply_gesture_settings
log "Initial gesture settings applied"

# Background daemon — monitor and re-apply if the system resets anything
while true; do
    sleep 3

    # Check if force_fsg_nav_bar got reset
    FSG_VAL=$(settings get global force_fsg_nav_bar 2>/dev/null)
    if [ "$FSG_VAL" != "1" ]; then
        log "force_fsg_nav_bar was reset to '$FSG_VAL', re-applying..."
        apply_gesture_settings
    fi

    # Check if gestural overlay got disabled
    GESTURAL_STATE=$(cmd overlay list 2>/dev/null | grep "com.android.internal.systemui.navbar.gestural" | head -1)
    if echo "$GESTURAL_STATE" | grep -q "^\[ \]"; then
        log "Gestural overlay was disabled, re-enabling..."
        apply_gesture_settings
    fi

    # Check if three-button overlay got re-enabled
    THREEBUTTON_STATE=$(cmd overlay list 2>/dev/null | grep "com.android.internal.systemui.navbar.threebutton" | head -1)
    if echo "$THREEBUTTON_STATE" | grep -q "^\[x\]"; then
        log "Three-button overlay was re-enabled, disabling..."
        apply_gesture_settings
    fi

    # Check if navigation_mode was reverted
    NAV_MODE=$(settings get secure navigation_mode 2>/dev/null)
    if [ "$NAV_MODE" != "2" ]; then
        log "navigation_mode was reset to '$NAV_MODE', re-applying..."
        apply_gesture_settings
    fi
done &

log "Daemon started with PID $!"
