#!/system/bin/sh
# post-fs-data.sh — Early boot gesture settings
# Runs at post-fs-data stage (blocking, before Zygote)

MODDIR=${0%/*}

# Set gesture navigation properties early
resetprop -n persist.sys.gesture_nav 1 2>/dev/null
resetprop -n ro.recents.grid 0 2>/dev/null
