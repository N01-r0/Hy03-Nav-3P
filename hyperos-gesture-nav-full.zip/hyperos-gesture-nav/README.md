# HyperOS Gesture Navigation for Third-Party Launchers

> **Force native HyperOS gesture navigation to work with any third-party launcher on rooted Xiaomi devices running HyperOS 2/3.**

Back gestures, home swipe, and recent apps — all working with Lawnchair, Niagara, Smart Launcher, Nova, or any launcher of your choice.

---

## The Problem

Xiaomi's HyperOS deliberately disables fullscreen gesture navigation when a third-party launcher is set as the default home app. The moment you switch from the stock launcher, the system forces you onto the three-button navigation bar. This is not a bug — it's an intentional architectural decision by Xiaomi.

Unlike other Android OEMs, Xiaomi embedded the entire gesture navigation engine directly into `com.miui.home` (the system launcher APK), rather than using Android's standard SystemUI-based gesture system. When a third-party launcher becomes the default, MiuiHome detects it is no longer the active home app and tears down all gesture input surfaces (`NavStubView`, `GestureStubLeft`, `GestureStubRight`), making gestures physically impossible.

Existing solutions like [AnyLauncher](https://github.com/tiann/AnyLauncher) and [FuckMIUIGesture](https://github.com/HCGStudio/FuckMIUIGesture) attempted to fix this via Xposed hooks, but both are **broken on HyperOS 3 / Android 16** due to renamed internal classes.

This project provides a working fix through direct APK patching of MiuiHome, combined with a KernelSU module that maintains the required system settings.

## How It Works — Technical Deep Dive

### Architecture: Why Xiaomi Is Different

On stock Android (Pixel, OnePlus, Samsung), gesture navigation is handled by two independent systems:

| Component | Handles | Location |
|---|---|---|
| **SystemUI** (AOSP) | Back gestures (left/right edge swipes) | `com.android.systemui` |
| **QuickStep provider** | Home + Recents (bottom swipe) | Configurable — usually the launcher |

On Xiaomi HyperOS, the architecture is different:

| Component | Handles | Location |
|---|---|---|
| **SystemUI** (AOSP) | Back gestures (partially) | `com.android.systemui` |
| **MiuiHome** | Back gestures (Xiaomi layer) + Home + Recents (ALL bottom gestures) | `com.miui.home` |

The critical difference: **SystemUI's QuickStep is hardwired to `com.miui.home`** via the framework config `mRecentsComponentName` and `mQuickStepIntent`. There is no API or setting to redirect it to another launcher.

### The Kill Chain (What Happens Without This Fix)

When you set a third-party launcher as default, MiuiHome executes this sequence within milliseconds:

1. `OverviewComponentObserver` detects the default home app changed
2. `BaseRecentsImpl.setIsUseMiuiHomeAsDefaultHome(false)` is called
3. `updateFsgWindowState()` checks `mIsUseMiuiHomeAsDefaultHome` — finds it `false`
4. `NavStubView` is destroyed: `removeNavStubView()`, `unregisterInputConsumer()`
5. `GestureStubLeft` and `GestureStubRight` are torn down: `clearGestureStub()`, `hideGestureStub()`
6. The system reverts to three-button navigation
7. `force_fsg_nav_bar` is reset to `0` by the system

### What This Fix Patches

The fix consists of **two components**: a patched MiuiHome APK (delivered via a KernelSU/Magisk module) and a standalone KernelSU module that maintains system settings.

#### Component 1: Patched MiuiHome APK (6 Patches)

All patches are applied to smali (Dalvik bytecode) and reassembled into the APK. No resources or signing are modified — only the DEX files are replaced.

| # | Target | Method | Change | Purpose |
|---|---|---|---|---|
| 1 | `BuildConfigUtils` | `isUseMiuiHomeAsDefaultHome()` | Always returns `true` | Prevents MiuiHome from detecting a third-party launcher is active |
| 2 | `BuildConfigUtils` | `isUsePocoHomeAsDefaultHome()` | Always returns `true` | Same fix for Poco-branded devices |
| 3 | `BaseRecentsImpl` | `setIsUseMiuiHomeAsDefaultHome(Z)V` | Forces parameter to `true` | Blocks runtime updates that would set the flag to `false` |
| 4 | `BaseRecentsImpl` | Constructor / init | Forces `mIsUseMiuiHomeAsDefaultHome = true` | Ensures the flag is correct from the moment MiuiHome boots |
| 5 | `NavStubView` | `lambda$performAppToRecents$36` (cond_8 fallback) | Launches `RecentsActivity` directly with `FLAG_ACTIVITY_NO_ANIMATION` | When the native recents animation path is unavailable (mLauncher is null), opens the recents screen as a standalone activity instead of falling back to the home gesture |
| 6 | `NavStubView` | `getHotSpaceHeight()` | Increases bottom gesture zone from 20.5dp to 35dp | Makes the swipe-up gesture easier to trigger (73% larger touch target) |

**Class rename discovery (HyperOS 3):** The key utility class was renamed from `com.miui.home.launcher.common.Utilities` (MIUI/HyperOS 1-2) to `com.miui.home.common.utils.BuildConfigUtils` (HyperOS 3). This is why AnyLauncher and FuckMIUIGesture fail on HyperOS 3 — their Xposed hooks target the old class name, and because all hooks are wrapped in a single try-catch block, every subsequent hook silently fails.

#### Component 2: force_gesture_nav KernelSU Module

A lightweight KernelSU/Magisk module that runs a background daemon to maintain gesture navigation settings. The system actively fights the configuration — resetting `force_fsg_nav_bar` to `0` periodically — so a persistent watcher is required.

| Script | When | What It Does |
|---|---|---|
| `post-fs-data.sh` | Early boot (before SystemUI) | Sets `force_fsg_nav_bar=1` and `navigation_mode=2` |
| `service.sh` | After boot complete | Enables gestural overlay, starts background daemon |
| Daemon (in `service.sh`) | Every 3 seconds | Monitors and re-applies: `force_fsg_nav_bar`, gestural overlay, navigation_mode |

## Requirements

| Requirement | Details |
|---|---|
| **Device** | Any Xiaomi / Redmi / Poco device running HyperOS 2 or HyperOS 3 |
| **Android version** | Android 15 or 16 |
| **Root** | KernelSU / KernelSU-Next / Magisk (any root solution that supports modules) |
| **Zygisk** | ZygiskNext (recommended) or Magisk's built-in Zygisk |
| **Framework** | Not required for this fix (LSPosed is NOT needed) |
| **Base launcher mod** | A KernelSU module that replaces MiuiHome APK (e.g., "Modded HyperOS Launcher" by Kashi, or your own) |

> **Note:** If you don't already have a modded launcher module, you can create a minimal one that just mounts the patched APK. See [Creating a Launcher Module from Scratch](#creating-a-launcher-module-from-scratch).

## Compatible Launchers

This fix works with **any** third-party launcher. The gesture engine runs inside MiuiHome regardless of which launcher is your default home app.

| Launcher | Back Gestures | Home Gesture | Recents Gesture | Notes |
|---|---|---|---|---|
| **Lawnchair** | Native quality | Works (minor home flash) | Works (opens RecentsActivity) | Has its own QuickStep service — could be even smoother with QuickSwitch |
| **Smart Launcher** | Native quality | Works (minor home flash) | Works (opens RecentsActivity) | Tested extensively |
| **Nova Launcher** | Native quality | Works (minor home flash) | Works (opens RecentsActivity) | — |
| **Niagara Launcher** | Native quality | Works (minor home flash) | Works (opens RecentsActivity) | — |
| **Any other launcher** | Native quality | Works (minor home flash) | Works (opens RecentsActivity) | If it can be set as default home, it works |

### Gesture Quality Breakdown

| Gesture | Quality | Explanation |
|---|---|---|
| **Back (left/right edge swipe)** | ★★★★★ Native | Handled by both SystemUI (AOSP) and MiuiHome's `GestureStubView` independently. Works identically to stock. Full arrow animation. |
| **Home (quick swipe up)** | ★★★★☆ Good | MiuiHome's shrink animation plays, but the transition routes briefly through MiuiHome before reaching your launcher. Results in a very brief visual flash. |
| **Recents (swipe up + hold)** | ★★★☆☆ Functional | Opens MiuiHome's RecentsActivity as a standalone screen. Works correctly but the transition is not as seamless as stock — you may see a brief home screen flash before recents appears. |

## Installation

### Prerequisites

1. Your device must be **rooted** with KernelSU, KernelSU-Next, or Magisk
2. You need a way to mount a modified MiuiHome APK (either an existing modded launcher module or create your own)
3. **APK signature verification must be disabled** (use a module like `DisableApkVerification` or equivalent)
4. ADB access from a computer

### Step 1: Install the force_gesture_nav Module

Download `force_gesture_nav_v1.0.zip` from the [Releases](../../releases) page.

**Option A — Flash via KernelSU/Magisk Manager:**

1. Open your root manager app (KernelSU Manager / Magisk Manager)
2. Go to Modules → Install from storage
3. Select `force_gesture_nav_v1.0.zip`
4. Reboot

**Option B — Install via ADB (direct file copy):**

```bash
# Push the module files directly
adb push force_gesture_nav/ /sdcard/force_gesture_nav_tmp/
adb shell "su -c 'mkdir -p /data/adb/modules/force_gesture_nav'"
adb shell "su -c 'cp -r /sdcard/force_gesture_nav_tmp/* /data/adb/modules/force_gesture_nav/'"
adb shell "su -c 'chmod 755 /data/adb/modules/force_gesture_nav/service.sh'"
adb shell "su -c 'chmod 755 /data/adb/modules/force_gesture_nav/post-fs-data.sh'"
adb shell "su -c 'chmod 755 /data/adb/modules/force_gesture_nav/uninstall.sh'"
adb reboot
```

### Step 2: Patch and Deploy MiuiHome APK

#### Automated (Recommended)

Download and run the patch script:

```bash
# Clone this repo
git clone https://github.com/user/hyperos-gesture-nav.git
cd hyperos-gesture-nav

# Pull MiuiHome from your device
adb shell "su -c 'cat /product/priv-app/MiuiHome/MiuiHome.apk'" > MiuiHome_original.apk

# Run the patcher (requires Java and smali.jar)
./patch_miuihome.sh MiuiHome_original.apk

# Deploy the patched APK
adb push MiuiHome_patched.apk /sdcard/
adb shell "su -c 'cp /sdcard/MiuiHome_patched.apk /data/adb/modules/YOUR_LAUNCHER_MOD/system/product/priv-app/MiuiHome/MiuiHome.apk'"
adb shell "su -c 'chmod 644 /data/adb/modules/YOUR_LAUNCHER_MOD/system/product/priv-app/MiuiHome/MiuiHome.apk'"
adb reboot
```

#### Manual Patching

If you prefer to understand and apply each patch yourself:

```bash
# 1. Decompile
apktool d MiuiHome.apk -o decompiled

# 2. Apply patches (see patches/ directory for exact changes)
# Patch 1-2: smali/com/miui/home/common/utils/BuildConfigUtils.smali
# Patch 3-4: smali_classes2/com/miui/home/recents/BaseRecentsImpl.smali
# Patch 5-6: smali_classes2/com/miui/home/recents/NavStubView.smali

# 3. Reassemble DEX files only (avoids resource compilation errors)
java -jar smali.jar assemble decompiled/smali -o classes.dex
java -jar smali.jar assemble decompiled/smali_classes2 -o classes2.dex
java -jar smali.jar assemble decompiled/smali_classes3 -o classes3.dex

# 4. Inject into original APK (preserves resources and signature)
cp MiuiHome.apk MiuiHome_patched.apk
zip -j MiuiHome_patched.apk classes.dex classes2.dex classes3.dex
```

> **Important:** Do NOT try to rebuild the full APK with `apktool b` — HyperOS uses private framework resources that apktool (even v2.10+) cannot compile. Instead, reassemble only the DEX files and inject them into a copy of the original APK using `zip`. This preserves all resources, assets, and the original signature.

### Step 3: Configure Your Launcher

1. **Before rebooting**, ensure gesture navigation is enabled: Settings → Home screen → System navigation → Gestures
2. Reboot
3. Set your third-party launcher as the default home app
4. Gestures should persist

### Verification

After setup, verify everything is working:

```bash
# Check gestural overlay is active
adb shell cmd overlay list | grep gestural
# Expected: [x] com.android.internal.systemui.navbar.gestural

# Check force_fsg_nav_bar
adb shell settings get global force_fsg_nav_bar
# Expected: 1

# Check gesture stubs are alive
adb shell "dumpsys input | grep GestureStub"
# Expected: GestureStubLeft, GestureStubRight, GestureStub all present

# Check daemon is running
adb shell "su -c 'cat /data/local/tmp/force_gesture_nav.log'" 
# Expected: Log entries showing daemon started and settings applied

# Check default home
adb shell cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME | grep packageName
# Expected: Your third-party launcher's package name
```

## Creating a Launcher Module from Scratch

If you don't have an existing modded launcher module, create a minimal one:

```
miui_home_gesture_patch/
├── module.prop
├── post-mount.sh
└── system/
    └── product/
        └── priv-app/
            └── MiuiHome/
                └── MiuiHome.apk    ← your patched APK
```

**module.prop:**
```
id=miui_home_gesture_patch
name=MiuiHome Gesture Navigation Patch
version=v1.0
versionCode=1
author=your_name
description=Patched MiuiHome to enable gesture navigation with third-party launchers
```

**post-mount.sh:**
```bash
#!/system/bin/sh
MODDIR=${0%/*}
mount -o bind ${MODDIR}/system/product/priv-app/MiuiHome/MiuiHome.apk /product/priv-app/MiuiHome/MiuiHome.apk
```

## Known Limitations

### Home Gesture Flash
When swiping up to go home, the transition briefly routes through MiuiHome's launcher before reaching your third-party launcher. This causes a very brief visual flash. This is an architectural limitation — MiuiHome's `performAppToHome()` animation system inherently brings its own launcher to the foreground as part of the shrink animation.

### Recents Transition
The recents gesture (swipe up + hold) opens `RecentsActivity` as a standalone activity rather than through the native animation pipeline. This means you may see a brief transition through the home screen before the recents view appears. The recents screen itself works correctly — you can see all your recent apps, swipe them away, and tap to switch.

### Why These Limitations Exist
MiuiHome's gesture animation system (`NavStubView → performAppToHome/performAppToRecents`) is deeply coupled to the MiuiHome launcher UI. The native animation path requires `mLauncher.getRecentsView().getTaskStackView()` — objects that only exist when MiuiHome's launcher activity is fully initialized and visible. When a third-party launcher is active, `mLauncher` is null, so the animation pipeline has no UI surface to animate against. The fix works around this by keeping the gesture engine alive while routing the final destination to RecentsActivity or the actual default home.

### Potential Future Improvement
Using [QuickSwitch](https://github.com/nickaknudson/QuickSwitch) with Lawnchair could theoretically redirect SystemUI's QuickStep provider to Lawnchair's own `TouchInteractionService`, enabling fully native gesture handling. However, QuickSwitch has not been updated for HyperOS 3's modified framework and would require significant adaptation.

## Tested Configuration

| Component | Version |
|---|---|
| Device | Xiaomi 17 Ultra (nezha) |
| OS | HyperOS 3 (V816) |
| Android | 16 (API 36) |
| Build | BP2A.250605.031.A3 |
| Root | KernelSU-Next (LKM mode) |
| Zygisk | ZygiskNext v1.3.3 |
| Launcher module | Modded HyperOS Launcher v6.6 (by Kashi) |
| Third-party launchers tested | Smart Launcher 6, Lawnchair |

## Troubleshooting

### Gestures stop working after switching launchers
The daemon should catch this within 3-5 seconds. If not, run manually:
```bash
adb shell "su -c 'cmd overlay enable com.android.internal.systemui.navbar.gestural'"
adb shell "su -c 'settings put global force_fsg_nav_bar 1'"
adb shell "su -c 'settings put secure navigation_mode 2'"
```

### MiuiHome crashes on boot
If the patched APK causes bootloops, disable the launcher module:
```bash
adb wait-for-device
adb shell "su -c 'touch /data/adb/modules/YOUR_LAUNCHER_MOD/disable'"
adb reboot
```

### Recents shows empty / no apps
This can happen if RecentsActivity hasn't been initialized since boot. Open the stock launcher once (switch back temporarily), then switch back to your third-party launcher.

### Three-button nav keeps coming back
Check the daemon log:
```bash
adb shell "su -c 'cat /data/local/tmp/force_gesture_nav.log'"
```
If the daemon isn't running, verify the module is active:
```bash
adb shell "su -c 'ls /data/adb/modules/force_gesture_nav/disable'" 
# Should return "No such file"
```

### Back gestures work but bottom gestures don't
This means the gestural overlay is active but MiuiHome's gesture engine didn't initialize. Reboot with gesture navigation enabled in Settings **before** switching to a third-party launcher.

## Project Structure

```
hyperos-gesture-nav/
├── README.md                          # This file
├── patches/                           # Individual patch descriptions
│   ├── 01_BuildConfigUtils.md
│   ├── 02_BaseRecentsImpl.md
│   └── 03_NavStubView.md
├── force_gesture_nav/                 # KernelSU module
│   ├── module.prop
│   ├── service.sh
│   ├── post-fs-data.sh
│   ├── system.prop
│   ├── customize.sh
│   ├── uninstall.sh
│   └── META-INF/
│       └── com/google/android/
│           ├── update-binary
│           └── updater-script
├── patch_miuihome.sh                  # Automated patch script
└── tools/
    └── smali.jar                      # smali assembler v2.5.2
```

## Credits & Prior Art

This project builds on the research and reverse engineering from:

- **[AnyLauncher](https://github.com/tiann/AnyLauncher)** by weishu/tiann — Identified the dual gesture system in MIUI and the key hooks needed. The approach of hooking `isUsePocoHomeAsDefaultHome`, `BaseRecentsImpl`, and `NavStubView.performAppToHome` was pioneered here.
- **[FuckMIUIGesture](https://github.com/HCGStudio/FuckMIUIGesture)** by HCGStudio — Identified the `force_fsg_nav_bar` setting and the SystemUI `MiuiFullScreenGestureProxy.updateDefaultHome` hook.
- **[QuickSwitch](https://github.com/nickaknudson/QuickSwitch)** — The concept of switching the recents/QuickStep provider at the framework level.
- **XDA Forums** — The [root tutorial thread](https://xdaforums.com/t/root-tutorial-working-gestures-with-any-launcher-for-every-miui-hyperos-device.4667872/) and [xiaomi.eu community](https://xiaomi.eu/community/threads/forcing-gesture-navigation-on-foreign-launchers.76170/) provided invaluable real-world testing data.

## License

MIT License. See [LICENSE](LICENSE) for details.

## Contributing

Contributions welcome. Key areas that need work:

- **Testing on other HyperOS 3 devices** — the class names may vary between device models
- **QuickSwitch integration** — adapting QuickSwitch for HyperOS 3's framework to enable Lawnchair as a native QuickStep provider
- **Smoother recents transition** — finding a way to eliminate the home-screen flash during the recents gesture
- **Automated patch script** — building a robust `patch_miuihome.sh` that handles different MiuiHome versions
