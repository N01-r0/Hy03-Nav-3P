#!/system/bin/sh
# Early boot hook — runs before SystemUI starts
# Sets gesture flags so SystemUI reads them during initialization
settings put global force_fsg_nav_bar 1 2>/dev/null
settings put secure navigation_mode 2 2>/dev/null
