#!/system/bin/sh
ui_print "============================================"
ui_print "  Force Gesture Navigation v1.0"
ui_print "  For HyperOS 2/3 + Third-Party Launchers"
ui_print "============================================"
ui_print ""
ui_print "  SETUP:"
ui_print "  1. Enable gesture navigation in Settings"
ui_print "     BEFORE switching to a 3rd party launcher"
ui_print "  2. Reboot"
ui_print "  3. Set your launcher as default"
ui_print ""
ui_print "  Log: /data/local/tmp/force_gesture_nav.log"
ui_print "============================================"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
