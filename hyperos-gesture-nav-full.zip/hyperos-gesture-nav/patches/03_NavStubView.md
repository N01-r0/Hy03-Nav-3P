# Patch 5 & 6: NavStubView

**File:** `smali_classes2/com/miui/home/recents/NavStubView.smali`

## Patch 5: Recents Fallback (performAppToRecents cond_8)

**Context:** When the user swipes up and holds (recents gesture), NavStubView calls `performAppToRecents()`, which posts a lambda (`lambda$performAppToRecents$36`) to the main thread. This lambda checks three conditions:

1. `isNeedStopBecauseRecentsRemoteAnimStartFailed()` — if true, abort
2. `isRecentsLoaded()` — checks if `mLauncher.getRecentsView().getTaskStackView()` exists
3. `isRecentsDisabled()` — system-level recents disable flag

With a third-party launcher active, `isRecentsLoaded()` returns `false` because `mLauncher` is null (MiuiHome's launcher UI isn't the active foreground activity). The code falls through to `cond_8`.

**Original cond_8 behavior:** Calls `performAppToHome()` — sends the user home instead of showing recents. Completely wrong behavior for a recents gesture.

**Patched cond_8 behavior:** Launches `RecentsActivity` directly as a standalone activity:

```smali
:cond_8
# Get context from the View
invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;
move-result-object v10

# Build Intent for RecentsActivity
new-instance v11, Landroid/content/Intent;
invoke-direct {v11}, Landroid/content/Intent;-><init>()V
new-instance v12, Landroid/content/ComponentName;
const-string v13, "com.miui.home"
const-string v14, "com.miui.home.recents.RecentsActivity"
invoke-direct {v12, v13, v14}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V
invoke-virtual {v11, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

# Flags: FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_CLEAR_TOP | FLAG_ACTIVITY_NO_ANIMATION
# 0x10000000 | 0x04000000 | 0x00010000 = 0x14010000
const v12, 0x14010000
invoke-virtual {v11, v12}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

# Launch it
invoke-virtual {v10, v11}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
```

**Why FLAG_ACTIVITY_NO_ANIMATION:** Without this flag, the system plays a default activity-open transition, which causes a visible flash through the home screen before RecentsActivity appears. The `NO_ANIMATION` flag suppresses this, making the transition less jarring.

### Why We Can't Use the Native Animation Path

We attempted patching `isRecentsLoaded()` to always return `true` (enabling the native recents animation), but this causes a crash:

```
java.lang.NullPointerException: Attempt to invoke virtual method
'getRecentsView()' on a null object reference
at NavStubView.initRecentsAnimation(NavStubView.java:2762)
```

The native animation pipeline fundamentally requires MiuiHome's launcher Activity to be running with its `RecentsView` UI hierarchy initialized. When a third-party launcher is active, these objects don't exist. The startActivity fallback is the only viable approach without a QuickStep provider redirect.

## Patch 6: Bottom Gesture Zone Height

**Method:** `getHotSpaceHeight()`

**Original behavior:** Returns the height of the bottom gesture capture zone:
- Fold devices: 25.0dp
- Hidden gesture line (`hide_gesture_line=1`): 20.5dp
- Default: 25.0dp

At ~2.39 display density (382dpi), 20.5dp = **48 pixels** — a very narrow strip at the bottom of the screen.

**Patched behavior:** Returns 35.0dp for all cases, yielding **~84 pixels** — a 73% increase in the touch target.

```smali
# ORIGINAL (hidden gesture line path)
const/high16 v1, 0x41a40000    # 20.5f

# PATCHED
const/high16 v1, 0x420c0000    # 35.0f
```

```smali
# ORIGINAL (default/fold path)
const/high16 v1, 0x41c80000    # 25.0f

# PATCHED
const/high16 v1, 0x420c0000    # 35.0f
```

**Float encoding reference:**
| Value | IEEE 754 Hex | const/high16 operand |
|---|---|---|
| 20.5f | 0x41A40000 | 0x41A40000 |
| 25.0f | 0x41C80000 | 0x41C80000 |
| 30.0f | 0x41F00000 | 0x41F00000 |
| 35.0f | 0x420C0000 | 0x420C0000 |
| 40.0f | 0x42200000 | 0x42200000 |

If 35dp is too large (interfering with app buttons at the bottom of the screen), you can use any value from the table above. The `const/high16` instruction requires the low 16 bits of the float to be zero, which is satisfied by all common dp values.
