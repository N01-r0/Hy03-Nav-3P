# Patch 1 & 2: BuildConfigUtils

**File:** `smali/com/miui/home/common/utils/BuildConfigUtils.smali`

> **HyperOS 3 note:** This class was renamed from `com.miui.home.launcher.common.Utilities` (MIUI 13 / HyperOS 1-2) to `com.miui.home.common.utils.BuildConfigUtils` (HyperOS 3). This is why AnyLauncher's Xposed hooks fail on HyperOS 3.

## Patch 1: isUseMiuiHomeAsDefaultHome

**Original behavior:** Checks if the current default home package equals `com.miui.home`. Returns `false` when a third-party launcher is active.

**Patched behavior:** Always returns `true`.

```smali
# ORIGINAL
.method public static isUseMiuiHomeAsDefaultHome(Landroid/content/Context;)Z
    .locals 1
    invoke-static {}, Lcom/miui/home/common/utils/BuildConfigUtils;->getCurrentDefaultHomePackageName()Ljava/lang/String;
    move-result-object p0
    const-string v0, "com.miui.home"
    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    move-result p0
    return p0
.end method

# PATCHED
.method public static isUseMiuiHomeAsDefaultHome(Landroid/content/Context;)Z
    .locals 1
    const/4 p0, 0x1
    return p0
.end method
```

## Patch 2: isUsePocoHomeAsDefaultHome

**Same pattern** applied to the Poco launcher check (`com.mi.android.globallauncher`).

```smali
# PATCHED
.method public static isUsePocoHomeAsDefaultHome(Landroid/content/Context;)Z
    .locals 1
    const/4 p0, 0x1
    return p0
.end method
```

## Why Both Patches Are Needed

MiuiHome checks both methods during initialization and when the default home changes. If either returns `false`, the gesture engine begins its teardown sequence. Patching both ensures coverage across Xiaomi and Poco branded devices.
