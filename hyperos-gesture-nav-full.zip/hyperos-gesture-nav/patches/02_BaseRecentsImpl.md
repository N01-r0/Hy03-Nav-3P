# Patch 3 & 4: BaseRecentsImpl

**File:** `smali_classes2/com/miui/home/recents/BaseRecentsImpl.smali`

## Patch 3: setIsUseMiuiHomeAsDefaultHome (Setter Method)

**Original behavior:** Accepts a boolean parameter from the system indicating whether MiuiHome is the default home. When a third-party launcher is set as default, this receives `false`, which triggers `updateUseLauncherRecentsAndFsGesture()` and `updateFsgWindowState()` — tearing down all gesture views.

**Patched behavior:** Forces the parameter to `true` before any logic executes.

```smali
# ADD at the very beginning of the method, after .locals 2
const/4 p1, 0x1    # Force parameter to true
```

This intercepts the kill signal at its entry point. Even when the system tries to set `mIsUseMiuiHomeAsDefaultHome = false`, the parameter is overwritten to `true` before the comparison and field assignment.

## Patch 4: Init-Time Field Assignment

**Original behavior:** During BaseRecentsImpl initialization, the field `mIsUseMiuiHomeAsDefaultHome` is set based on comparing the current default home package name with MiuiHome's package name:

```smali
invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
move-result v0
if-eqz v0, :cond_3
move v4, v2            # v4 = true only if package matches
:cond_3
iput-boolean v4, p0, ...;->mIsUseMiuiHomeAsDefaultHome:Z
```

**Patched behavior:** Inserts `const/4 v4, 0x1` just before the `iput-boolean`, ensuring the field is always set to `true` regardless of the package comparison result.

```smali
:cond_3
const/4 v4, 0x1    # PATCHED: Force true at init
iput-boolean v4, p0, ...;->mIsUseMiuiHomeAsDefaultHome:Z
```

## The Downstream Effect

When `mIsUseMiuiHomeAsDefaultHome` is `true`, the critical method `updateFsgWindowState()` follows this path:

```
if (force_fsg_nav_bar == true AND mIsUseMiuiHomeAsDefaultHome == true)
    → createAndAddNavStubView()    ← gesture views CREATED
    → addBackStubWindow()          ← back gesture windows CREATED
else
    → removeNavStubView()          ← gesture views DESTROYED
```

By ensuring the flag is always `true`, gesture views are created on boot and never torn down.
